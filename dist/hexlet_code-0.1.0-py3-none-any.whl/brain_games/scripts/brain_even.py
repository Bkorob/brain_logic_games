#!/usr/bin/env python3


from brain_games.even import has_even


def main():
    has_even()


if __name__ == '__main__':
    main()
