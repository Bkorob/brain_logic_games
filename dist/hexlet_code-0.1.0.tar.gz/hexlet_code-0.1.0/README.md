# python-project-49
https://semver.org/lang/ru/#spec-item-1
