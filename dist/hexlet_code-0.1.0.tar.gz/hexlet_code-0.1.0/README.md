# python-project-49
https://semver.org/lang/ru/#spec-item-1

<a href="https://codeclimate.com/github/Bkorob/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/eee06181155c8e14ef34/maintainability" /></a>
