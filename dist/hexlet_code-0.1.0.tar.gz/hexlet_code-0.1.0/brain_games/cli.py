#!/usr/bin/env python3

inport prompt

def welcome_user()


    name = prompt.string('May I have your name? ')
    print(f'Hello,{name}!')
