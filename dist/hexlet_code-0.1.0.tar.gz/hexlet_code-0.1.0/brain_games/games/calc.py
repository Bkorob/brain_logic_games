import random


QUESTION = "What is the result of the expression?"


def game():
    num_first = random.randint(0,100)
    num_second = random.randint(0,100)
    oper = random.choice('-+*')
    screen_question = f'{num_first} {oper} {num_second}'
    result = 0
    if oper == '-':
        result = num_first - num_second
    elif oper == '+':
        result = num_first + num_second
    elif oper == '*':
        result = num_first * num_second
    screen_answer = str(result)
    return screen_question, screen_answer


